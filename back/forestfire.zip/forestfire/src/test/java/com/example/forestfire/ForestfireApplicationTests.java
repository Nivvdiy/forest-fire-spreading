package com.example.forestfire;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ForestfireApplicationTests {

	@Test
	void contextLoads() {
	}

}
